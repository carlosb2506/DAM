import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {
    static int contadorClientes = 0;

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(5000)) {
            System.out.println("Servidor escuchando el puerto 5000");

            while (true) {
                Socket clienteSocket = serverSocket.accept();
                try {
					contadorClientes++;
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                System.out.println("Cliente " + contadorClientes + " esta conectado");

                new Thread(new ManejadorCliente(clienteSocket, contadorClientes)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

class ManejadorCliente implements Runnable {
    private Socket clienteSocket;
    private int clienteId;

    public ManejadorCliente(Socket clienteSocket, int clienteId) {
        this.clienteSocket = clienteSocket;
        this.clienteId = clienteId;
    }

    @Override
    public void run() {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(clienteSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clienteSocket.getOutputStream(), true);

            String mensaje = in.readLine();
            System.out.println("Mensaje del cliente " + clienteId + ": " + mensaje);

            out.println("Mensaje recibido corretamente");

            clienteSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


