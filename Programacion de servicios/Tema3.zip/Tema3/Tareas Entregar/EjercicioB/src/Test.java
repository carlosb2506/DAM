public class Test {

    public static void main(String[] args) {

        Thread hiloServidor = new Thread(() -> {
            Servidor.main(null);
        });
        hiloServidor.start();

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        for (int i = 1; i <= 5; i++) {
            new Thread(() -> {
                Cliente.main(new String[]{});
            }).start();
        }
    }
}

