package com.example.barrosocarlos;

import android.os.Bundle;
import android.text.Layout;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private Button btnGenerar, btnPassword;
    private RadioButton rbGenerar, rbComprobar;
    private LinearLayout layoutGenerada, layoutBotones, layoutLongitud;

    private TextView  tvContraGenerada;
    private EditText etLong;

    private CheckBox cbMayus, cbNum, cbSimb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        btnGenerar = findViewById(R.id.btnGenerar);
        btnPassword = findViewById(R.id.btnPassword);

        rbGenerar = findViewById(R.id.rbGenerar);
        rbComprobar = findViewById(R.id.rbComprobar);
        cbMayus = findViewById(R.id.cbMayus);
        cbNum = findViewById(R.id.cbNum);
        cbSimb = findViewById(R.id.cbSimb);
        etLong = findViewById(R.id.etLong);

        tvContraGenerada = findViewById(R.id.tvContraGenerada);

        layoutLongitud = findViewById(R.id.layoutLongitud);
        layoutBotones = findViewById(R.id.layoutBotones);
        layoutGenerada = findViewById(R.id.layoutGenerada);


        layoutGenerada.setVisibility(View.INVISIBLE);
        layoutBotones.setVisibility(View.INVISIBLE);
        layoutLongitud.setVisibility(View.INVISIBLE);
    }

    public void  password(View view){
        if (rbGenerar.isChecked()) {
            layoutBotones.setVisibility(View.VISIBLE);
            layoutGenerada.setVisibility(View.VISIBLE);
            layoutLongitud.setVisibility(View.VISIBLE);
        }

    }

    public void generar(View view){
        //int minusAleatorio = (int)(Math.random() * (122-97)) + 97;
        //int mayusAleatorio = (int)(Math.random() * (90-65)) + 65;
        //int simAleatorio = (int)(Math.random() * (64-33)) + 33;
        String contrasenia = "";
        int iteracciones = Integer.parseInt(etLong.getText().toString());
        if (etLong.getText().toString().equals("")) {
            Toast.makeText(this, "Mensaje largo", Toast.LENGTH_LONG). show();
        }else if ((cbMayus.isChecked()) && (!cbNum.isChecked()) && (!cbSimb.isChecked())) {
            for (int i = 0; i < iteracciones; i++)
            {
                int numAle = (int)(Math.random() * (3-1) + 1);
                if (numAle == 2){
                    contrasenia += (char)(Math.random() * (90-65) + 65); // Aleatorio para mayusculas
                }else {
                    contrasenia += (char) (Math.random() * (122 - 97) + 97);
                }


            }
            tvContraGenerada.setText(contrasenia);
        }else if ((!cbMayus.isChecked()) && (!cbNum.isChecked()) && (cbSimb.isChecked())) {
            Log.d("Debug", "por los simbolos pasa");
            for (int i = 0; i < iteracciones; i++)
            {
                int numAle = (int)(Math.random() * (3-1) + 1);
                if (numAle == 2){
                    contrasenia += (char)(Math.random() * (47-33) + 33); // aleatorio para simbolos
                }else {
                    contrasenia += (char) (Math.random() * (122 - 97) + 97);
                }
            }
            tvContraGenerada.setText(contrasenia);
        }else if ((!cbMayus.isChecked()) && (cbNum.isChecked()) && (!cbSimb.isChecked())) {
            for (int i = 0; i < iteracciones; i++)
            {
                int numAle = (int)(Math.random() * (3-1) + 1);
                if (numAle == 2){
                    contrasenia += (int)(Math.random() * (9-1) + 9); //aleatorio para numeros
                }else {
                    contrasenia += (char) (Math.random() * (122 - 97) + 97);
                }
            }
            tvContraGenerada.setText(contrasenia);
        }else if ((!cbMayus.isChecked()) && (!cbNum.isChecked()) && (!cbSimb.isChecked())) {
            for (int i = 0; i < iteracciones; i++)
            {
                contrasenia += (char)(Math.random() * (122-97) + 97); // Aleatorio para minusculas

            }
            tvContraGenerada.setText(contrasenia);
        }
        else if ((cbMayus.isChecked()) && (cbNum.isChecked()) && (cbSimb.isChecked())) {
            for (int i = 0; i < iteracciones; i++)
            {
                int numAle = (int)(Math.random() * (5-1) + 1);
                if (numAle == 2){
                    contrasenia += (int)(Math.random() * (9-1) + 9);
                }else if (numAle == 3) {
                    contrasenia += (char) (Math.random() * (122 - 97) + 97);
                } else if (numAle == 1) {
                    contrasenia += (char)(Math.random() * (47-33) + 33);
                }else {
                    contrasenia += (char)(Math.random() * (90-65) + 65);
                }

            }
            tvContraGenerada.setText(contrasenia);
        }else if ((cbMayus.isChecked()) && (!cbNum.isChecked()) && (cbSimb.isChecked())) {
            for (int i = 0; i < iteracciones; i++)
            {
                int numAle = (int)(Math.random() * (4-1) + 1);

                if (numAle == 2) {
                    contrasenia += (char) (Math.random() * (122 - 97) + 97);
                } else if (numAle == 1) {
                    contrasenia += (char)(Math.random() * (47-33) + 33);
                }else {
                    contrasenia += (char)(Math.random() * (90-65) + 65);
                }

            }
            tvContraGenerada.setText(contrasenia);
        }else if ((!cbMayus.isChecked()) && (cbNum.isChecked()) && (cbSimb.isChecked())) {
            for (int i = 0; i < iteracciones; i++)
            {
                int numAle = (int)(Math.random() * (4-1) + 1);

                if (numAle == 2) {
                    contrasenia += (char) (Math.random() * (122 - 97) + 97);
                } else if (numAle == 1){
                    contrasenia += (char)(Math.random() * (47-33) + 33);
                } else {
                    contrasenia += (int)(Math.random() * (9-1) + 9);
                }

            }
            tvContraGenerada.setText(contrasenia);
        }else if ((cbMayus.isChecked()) && (cbNum.isChecked()) && (!cbSimb.isChecked())) {
            for (int i = 0; i < iteracciones; i++)
            {
                int numAle = (int)(Math.random() * (4-1) + 1);

                if (numAle == 2) {
                    contrasenia += (char) (Math.random() * (122 - 97) + 97);
                } else if (numAle == 1){
                    contrasenia += (char)(Math.random() * (90-65) + 65);
                } else {
                    contrasenia += (int)(Math.random() * (9-1) + 9);
                }
            }
            tvContraGenerada.setText(contrasenia);
        }
    }
}