package com.example.ejercicio3;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Actividad2 extends Activity {

    private Button btnVolver;
    private ArrayList<Bar> listaBares; // Especificar el tipo de elementos
    private RecyclerView rvBares;

    private RecyclerAdaptador adaptador;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {


        super.onCreate(savedInstanceState); // Llamar al super primero

        setContentView(R.layout.layout_actividad2);

        btnVolver = findViewById(R.id.btnVolver);
        rvBares = findViewById(R.id.rvBares);


        rvBares.setLayoutManager(new GridLayoutManager(this, 2));


        llenarLista();
        adaptador = new RecyclerAdaptador(listaBares);
        rvBares.setAdapter(adaptador);
    }

    public void llenarLista() {
        listaBares = new ArrayList<>();
        listaBares.add(new Bar(R.drawable.bar_cuatro_calles, "Bar Cuatro Calles", "C/ Nueva, Nº42"));
        listaBares.add(new Bar( R.drawable.bar_polear,"Café Bar Polear", "C/ Virgen de los Remedios, Nº6"));
        listaBares.add(new Bar(R.drawable.bar_que_punto,"Bar QUE PUNTO", "C/ la Huerta, Nº15"));
        listaBares.add(new Bar(R.drawable.sin_foto,"Cervercería El Sitio", "C/ Virgen de los Remedios, Nº3"));
        listaBares.add(new Bar(R.drawable.bar_la_fabrica,"Restaurante La Fabrica Y Terraza La Pasailla", "C/ Meson, Nº11"));
        listaBares.add(new Bar(R.drawable.sin_foto,"Restaurante La Bodeguita", "C/ Velazquez, Nº9"));
        listaBares.add(new Bar(R.drawable.meson_sabor_andaluz,"Mesón Sabor Andaluz", "C/ la Huerta, Nº3"));
        listaBares.add(new Bar(R.drawable.sin_foto,"Bar Plaza", "Plaza Ayuntamiento, Nº12"));
    }

    public void volver(View view) {
        finish();
    }
}

