package com.example.comunicacionactividades;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerAdaptador adaptador;
    private RecyclerView rv_recetas;
    private ArrayList<Recetas> lista;
    private ActivityResultLauncher intercambio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        LinearLayoutManager layout = new LinearLayoutManager(this);
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Recojo los resultados que me devuelve la actividad.
        intercambio = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult o) {
                int duracion, posicion;
                String pasos;
                //Sólo modificamos la lista si se ha hecho algún cambio y se ha pulsado
                // el botón aceptar.
                if (o != null && o.getResultCode() == RESULT_OK )
                {
                    duracion = o.getData().getIntExtra("Duracion", 0);
                    posicion = o.getData().getIntExtra("Posicion", -1);
                    pasos = o.getData().getStringExtra("Pasos");
                    adaptador.modificarReceta(posicion, duracion, pasos);
                }
            }
        });

        rv_recetas = findViewById(R.id.rv_recetas);
        rv_recetas.setLayoutManager(layout);
        lista = new ArrayList<>();
        lista.add(new Recetas("Puchero andaluz", R.drawable.puchero_andaluz_tradicional, "Media", 120, "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum"));
        adaptador = new RecyclerAdaptador(lista, this);
        rv_recetas.setAdapter(adaptador);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        boolean devolver = true;
        Intent i;
        Recetas receta;
        switch(item.getItemId())
        {
            case 121:
                //Borra el registro seleccionado.
                adaptador.borrar(item.getGroupId());
                break;
            case 122:
                //Modificar datos
                int posicion = item.getGroupId();
                i = new Intent(this, ModificarRecetas.class);
                receta = adaptador.devolverReceta(posicion);
                i.putExtra("Nombre", receta.getNombre());
                i.putExtra("Foto", receta.getFoto());
                i.putExtra("Pasos", receta.getPasos());
                i.putExtra("Duracion", receta.getTiempo());
                i.putExtra("Posicion", posicion);
                intercambio.launch(i);
                break;
            default:
                devolver = super.onContextItemSelected(item);
                break;
        }

        return devolver;
    }
}