package Ejercicio4;

public class Main {

	public static void main(String[] args) {
		
		PiscinaDAO piscina = new PiscinaDAO();
		
		//Este metodo funciona.
		//piscina.TraerPiscina();
		
		//Este metodo funciona.
		//piscina.TraerPiscinaConcreta("2021");
		
		//Este metodo funciona.
		//piscina.DiferenciaAnios("2021-02-25");
		
		//Este metodo funciona.
		//piscina.InsertarBatch();
		
		//Este metodo funciona.
		//piscina.OrdenarRegistrosFecha();
		
		//Este metodo funciona.
		//piscina.OrdenarRegistrosFecha2();
		
		//Este no funciona
		piscina.OrdenarRegistrosFecha3();

	}

}
