package jugadores;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

public class EquipoDAO {

	// IMPLEMENTADO CORRECTAMENTE
	public static void mostrarJugadoresEquipo(String cif) {

		try (Connection con = Database.conectar()) {
			String sql = "SELECT jugador FROM asignacion WHERE equipo = ?;";

			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, cif);

			ResultSet rs = ps.executeQuery();
			boolean jugadorEncontrado = false;

			while (rs.next()) {
				jugadorEncontrado = true;

				String sql2 = "SELECT nombre, edad FROM jugador WHERE dni = ?;";
				PreparedStatement ps2 = con.prepareStatement(sql2);
				ps2.setString(1, rs.getString("jugador"));

				ResultSet rs2 = ps2.executeQuery();

				System.out.println(rs2.getString("nombre") + " " + rs2.getInt("edad"));
			}

			if (!jugadorEncontrado) {
				System.out.println("No se encontraron usuarios que jueguen a ese juego.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// IMPLEMENTADO CORRECTAMENTE
	public static void ayuda() {

		try (Connection con = Database.conectar()) {
			String sql = "SELECT * FROM equipo;";

			PreparedStatement ps = con.prepareStatement(sql);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				if (rs.getInt("presupuesto") < 30000) {
					String sql2 = "UPDATE equipo SET presupuesto = ? WHERE cif = ?;";
					PreparedStatement ps2 = con.prepareStatement(sql2);
					ps2.setInt(1, (rs.getInt("presupuesto") + 30000));
					ps2.setString(2, rs.getString("cif"));

					ps2.executeUpdate();
				}

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void Pagar(String cif) {

		try (Connection con = Database.conectar()) {
			String sql = "SELECT jugador FROM asignacion WHERE equipo = ?;";

			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, cif);

			ResultSet rs = ps.executeQuery();
			boolean jugadorEncontrado = false;
			int totalPagar = 0;

			while (rs.next()) {
				jugadorEncontrado = true;

				String sql2 = "SELECT sueldo FROM jugador WHERE dni = ?;";
				PreparedStatement ps2 = con.prepareStatement(sql2);
				ps2.setString(1, rs.getString("jugador"));

				ResultSet rs2 = ps2.executeQuery();

				System.out.println(rs2.getInt("sueldo"));
				totalPagar += rs2.getInt("sueldo");

			}
			String sql3 = "SELECT presupuesto FROM equipo WHERE cif = ?;";
			PreparedStatement ps3 = con.prepareStatement(sql3);
			ps3.setString(1, cif);

			ResultSet rs3 = ps3.executeQuery();
			
			String sql4 = "UPDATE equipo SET presupuesto = ? WHERE cif = ?;";
			PreparedStatement ps4 = con.prepareStatement(sql4);
			ps4.setInt(1, (rs3.getInt("presupuesto") - totalPagar));
			ps4.setString(2, cif);

			ps4.executeUpdate();

			if (!jugadorEncontrado) {
				System.out.println("No se encontraron usuarios que jueguen a ese juego.");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
