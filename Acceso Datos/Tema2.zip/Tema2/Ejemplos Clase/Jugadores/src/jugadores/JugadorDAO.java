package jugadores;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JugadorDAO {
	
	
	//IMPLEMENTADO CORRECTAMENTE
	public void insertJugador(Jugador jug) {
		String sql = "INSERT INTO jugador " + "(dni, nombre,edad, sueldo)" + "VALUES (?, ?, ?, ?);";
		try (Connection con = Database.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setString(1, jug.getDni());
			ps.setString(2, jug.getNombre());
			ps.setInt(3, jug.getEdad());
			ps.setInt(4, jug.getSueldo());
			ps.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	//IMPLEMENTADO CORRECTAMENTE
	public void insertJugadorEnEquipo(String dni, String cif) {
		
		try (Connection con = Database.conectar()) {
			
			con.setAutoCommit(false);
			
			String sql = "INSERT INTO asignacion " + "(jugador, equipo)" + "VALUES (?, ?);";
			PreparedStatement ps = con.prepareStatement(sql);

				ps.setString(1, dni);
				ps.setString(2, cif);

			ps.execute();

			con.commit();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//IMPLEMENTADO CORRECTAMENTE
	public void eliminarJugador(String dni) {
		
		String sql = "DELETE FROM asignacion where jugador = ?;";
		try (Connection con = Database.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
			con.setAutoCommit(false);
			ps.setString(1, dni);
			ps.execute();
			
			String sql2 = "UPDATE jugador SET sueldo = ? WHERE dni = ?;";
			PreparedStatement ps2 = con.prepareStatement(sql2);

			ps2.setInt(1, 0);
			ps2.setString(2, dni);
			
			ps.execute();
			ps2.execute();
			
			// Commit si todo ha ido bien
			con.commit();

			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
