package jugadores;

public class Test {

	public static void main(String[] args) {
		
		JugadorDAO j1 = new JugadorDAO();
		EquipoDAO e1 = new EquipoDAO();
		
		j1.insertJugador(new Jugador("25631203D", "Carlos Barroso", 20, 1000000));
		
		
		j1.insertJugadorEnEquipo("25631203D","G45678901");
		e1.mostrarJugadoresEquipo("F34567890");
		
		j1.eliminarJugador("34567890C");
		
		e1.ayuda();
		e1.Pagar("E23456789");
	}
}
