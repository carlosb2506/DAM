package jugadores;

public class Equipo {
	
	private String cif;
	private String nombre;
	private int presupuesto;
	public String getCif() {
		return cif;
	}
	public void setCif(String cif) {
		this.cif = cif;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getPresupuesto() {
		return presupuesto;
	}
	public void setPresupuesto(int presupuesto) {
		this.presupuesto = presupuesto;
	}
	@Override
	public String toString() {
		return "Equipo [cif=" + cif + ", nombre=" + nombre + ", presupuesto=" + presupuesto + ", toString()="
				+ super.toString() + "]";
	}
	public Equipo(String cif, String nombre, int presupuesto) {
		super();
		this.cif = cif;
		this.nombre = nombre;
		this.presupuesto = presupuesto;
	}

}
