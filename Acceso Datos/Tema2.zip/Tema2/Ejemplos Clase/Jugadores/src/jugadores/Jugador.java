package jugadores;

public class Jugador {
	
	private String dni;
	private String nombre;
	private int edad;
	private int sueldo;
	
	public Jugador(String dni, String nombre, int edad, int sueldo) {
		this.dni = dni;
		this.nombre = nombre;
		this.edad = edad;
		this.sueldo = sueldo;
	}

	public String getDni() {
		return dni;
	}
	
	public void setDni(String dni) {
		this.dni = dni;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public int getEdad() {
		return edad;
	}
	
	public void setEdad(int edad) {
		this.edad = edad;
	}
	
	public int getSueldo() {
		return sueldo;
	}
	
	public void setSueldo(int sueldo) {
		this.sueldo = sueldo;
	}

	@Override
	public String toString() {
		return "Jugador [dni=" + dni + ", nombre=" + nombre + ", edad=" + edad + ", sueldo=" + sueldo + ", toString()="
				+ super.toString() + "]";
	}
}
