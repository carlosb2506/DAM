module Tutorial7 {
	requires javafx.controls;
	requires javafx.fxml;
	requires java.desktop;
	requires javafx.graphics;
	
	opens application to javafx.base, javafx.graphics, javafx.fxml;
}
