﻿// See https://aka.ms/new-console-template for more information
using EjemploHerencia;

Cuadrado cuadrado = new Cuadrado();

Console.WriteLine(cuadrado.ToString());

Triangulo triangulo = new Triangulo();