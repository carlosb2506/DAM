﻿using System;

    public static class Constantes
    {
        public const int NUMLADOS = 3;
        public const int MEDLADOS = 1;
        public const int CUADRADO = 4;
        public const int TRIANGULO = 3;
    }
