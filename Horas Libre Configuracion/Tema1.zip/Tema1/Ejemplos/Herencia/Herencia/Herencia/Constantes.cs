﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public static class Constantes
{
    public const int ANIO = 1895;

    public const double PRECIOMINUTO = 0.1;

    public const int PRECIOVJ = 10;
}

