﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio3
{
    public class Constantes
    {
        public const int SOBREPESO = 1;
        public const int IDEAL = 0;
        public const int BAJOPESO = -1;
    }
}
