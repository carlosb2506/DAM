﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Constantes
{
    public const int VIDA_SACERDOTE = 100;
    public const int ENERGIA_SACERDOTE = 80;
    public const int VIDA_CURANDERO = 50;
    public const int ENERGIA_CURANDERO = 100;
    public const int DIFUNTO = 0;
}

